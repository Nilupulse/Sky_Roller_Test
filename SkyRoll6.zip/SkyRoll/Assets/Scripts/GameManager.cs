﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public bool canPlay;
    public bool standby;
    public bool isFirstTime;
    public int playerGemCount;
    public int progressNo;
    public float boostTime;
    public List<LevelData> levelData = new List<LevelData>();
    public List<GameObject> levels = new List<GameObject>();
    public GameObject hitObject;
    
    LevelData currentLevelData;
    GameObject currentLevel;

    public enum GameStatus 
    {
        STANDBY,
        PLAYING,
        REVIVE,
        WIN,
        HIT,
        GAMEOVER
    }
    public GameStatus gameStatus;

    void Awake()
    {
        if (!Instance)
        {
            Instance = this;
        }
    }
    void Start()
    {
       PlayerPrefs.DeleteAll();
        canPlay = false;
        progressNo = DataHandler.Instance.GetIntData("ProgressNo") ;
        playerGemCount = DataHandler.Instance.GetIntData("GemCount");
        isFirstTime = DataHandler.Instance.GetPlayerStatus("IsFirstTime");
        boostTime = 3f;
        SetCurrentLevel();
        UIHandler.Instance.StartGame();
    }
    public void SetCurrentLevel() 
    {
        isFirstTime = DataHandler.Instance.GetPlayerStatus("IsFirstTime");
        if (progressNo <= 2)
        {

            if (isFirstTime)
            {
                print("A");
                currentLevelData = levelData[progressNo];
                currentLevel = Instantiate(levels[progressNo]) as GameObject;
            }
            else
            {
                print("B"+ progressNo);
                currentLevelData = null;
                if (!currentLevel) 
                {
                    Destroy(currentLevel);
                }
                currentLevelData = levelData[progressNo];
                currentLevel = Instantiate(levels[progressNo]) as GameObject;
                
            }
            UIHandler.Instance.SetGameInfo(currentLevelData);
        }
        else
        {
            UIHandler.Instance.DemoComplete();
        }
        
    }
    public void GameOver()
    {
        canPlay = false;
        UIHandler.Instance.GameOverUI();
    }
    public void LevelCompleted() 
    {

        progressNo++;
        DataHandler.Instance.SaveData("ProgressNo", progressNo);
        gameStatus = GameStatus.WIN;
        PlayerMovements.Instance.SlowDownPlayer();
        currentLevelData.isCompleted = true;
        UIHandler.Instance.GameWin();
        UIHandler.Instance.ActivateCompletedLevel();
        if (currentLevelData.levelID == 4)
        {
            UIHandler.Instance.ResetActivateCompletedLevel();
        }        

    }
    public void SetHitObject(GameObject _hitObject) 
    {
        hitObject=null;
        hitObject = _hitObject;
    }
    public void ReviveGame() 
    {
        Destroy(hitObject);
        gameStatus = GameStatus.STANDBY;
    }
    public void LoadLevel() 
    {
        PlayerMovements.Instance.ResetPlayer();
        SetCurrentLevel();
        gameStatus = GameStatus.STANDBY;
    }
}
